# RankSmart – SEO Audit Team (ADK)

Start (local):
1) Activate venv, then run: `.venv\Scripts\adk.exe web` from the parent of `ai_seo_audit_team`
2) Open: http://127.0.0.1:8000/dev-ui/?app=ai_seo_audit_team